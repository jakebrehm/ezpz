# EZPZ Lemon Squeezy

A package that makes things easy.